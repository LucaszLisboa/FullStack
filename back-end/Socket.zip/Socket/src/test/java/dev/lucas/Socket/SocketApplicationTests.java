package dev.lucas.Socket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
