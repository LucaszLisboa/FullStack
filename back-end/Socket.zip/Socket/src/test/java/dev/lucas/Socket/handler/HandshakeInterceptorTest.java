package dev.lucas.Socket.handler;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HandshakeInterceptorTest {

    @Test
    void getSuperHero() {

        HandshakeInterceptor handshakeInterceptor = new HandshakeInterceptor();


    }
}